export class User {

    id: number;
    nombre: string;
    apellido: string;


}
